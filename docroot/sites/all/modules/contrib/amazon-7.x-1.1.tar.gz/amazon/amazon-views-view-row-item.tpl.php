<?php
/**
 * @file amazon-views-view-row-item.tpl.php
 * Default simple view template to display a single Amazon item.
 *
 *
 * @ingroup views_templates
 */
?>
<?php print $content; ?>
